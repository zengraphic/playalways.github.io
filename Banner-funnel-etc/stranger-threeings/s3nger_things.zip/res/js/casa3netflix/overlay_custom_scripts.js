function dissolveOverlay() {
    var particlesPromise =
        $('#particles-js-1,#particles-js-2,#particles-js-3')
        .fadeOut(600);
    var overlayHeaderPromise =
        $('.overlay-header')
        .fadeOut(600);


    $.when(particlesPromise, overlayHeaderPromise)
        .then(function() {
            $('.particles-background')
                .fadeOut(600)
                .css({
                    'cursor': 'default'
                });
        });
}

var conf1 = {
    "particles": {
        "number": {
            "value": 10,
            "density": {
                "enable": true,
                "value_area": 1000
            }
        },
        "color": {
            "value": "#000"
        },
        "shape": {
            "type": "image",
            "stroke": {
                "width": 0,
                "color": "#141414"
            },
            "polygon": {
                "nb_sides": 5
            },
            "image": {
                "src": "res/imgs/casa3netflix/Netflix-duster-1.png",
                "width": 100,
                "height": 100
            }
        },
        "opacity": {
            "value": 0.2,
            "random": true,
            "anim": {
                "enable": true,
                "speed": 0.2,
                "opacity_min": 0.1,
                "sync": false
            }
        },
        "size": {
            "value": 15,
            "random": true,
            "anim": {
                "enable": true,
                "speed": 5,
                "size_min": 10,
                "sync": false
            }
        },
        "line_linked": {
            "enable": false,
            "distance": 500,
            "color": "#ffffff",
            "opacity": 0.4,
            "width": 2
        },
        "move": {
            "enable": true,
            "speed": 0.3,
            "direction": "top",
            "random": true,
            "straight": false,
            "out_mode": "out",
            "bounce": false,
            "attract": {
                "enable": false,
                "rotateX": 600,
                "rotateY": 600
            }
        }
    },
    "interactivity": {
        "detect_on": "canvas",
        "events": {
            "onhover": {
                "enable": true,
                "mode": "bubble"
            },
            "onclick": {
                "enable": true,
                "mode": "bubble"
            },
            "resize": true
        },
        "modes": {
            "grab": {
                "distance": 400,
                "line_linked": {
                    "opacity": 0.5
                }
            },
            "bubble": {
                "distance": 300,
                "size": 3,
                "duration": 0.2,
                "opacity": 0.2,
                "speed": 3
            },
            "repulse": {
                "distance": 50,
                "duration": 1
            },
            "push": {
                "particles_nb": 4
            },
            "remove": {
                "particles_nb": 2
            }
        }
    }
};

var conf2 = {
    "particles": {
        "number": {
            "value": 35,
            "density": {
                "enable": true,
                "value_area": 500
            }
        },
        "color": {
            "value": "#000"
        },
        "shape": {
            "type": "image",
            "stroke": {
                "width": 0,
                "color": "#141414"
            },
            "polygon": {
                "nb_sides": 5
            },
            "image": {
                "src": "res/imgs/casa3netflix/Netflix-duster-2.png",
                "width": 100,
                "height": 100
            }
        },
        "opacity": {
            "value": 0.7,
            "random": true,
            "anim": {
                "enable": true,
                "speed": 1,
                "opacity_min": 0.5,
                "sync": false
            }
        },
        "size": {
            "value": 10,
            "random": true,
            "anim": {
                "enable": true,
                "speed": 2,
                "size_min": 5,
                "sync": false
            }
        },
        "line_linked": {
            "enable": false,
            "distance": 500,
            "color": "#ffffff",
            "opacity": 0.4,
            "width": 2
        },
        "move": {
            "enable": true,
            "speed": 0.3,
            "direction": "left",
            "random": true,
            "straight": false,
            "out_mode": "out",
            "bounce": false,
            "attract": {
                "enable": false,
                "rotateX": 600,
                "rotateY": 600
            }
        }
    },
    "interactivity": {
        "detect_on": "canvas",
        "events": {
            "onhover": {
                "enable": true,
                "mode": "bubble"
            },
            "onclick": {
                "enable": true,
                "mode": "bubble"
            },
            "resize": true
        },
        "modes": {
            "grab": {
                "distance": 400,
                "line_linked": {
                    "opacity": 0.5
                }
            },
            "bubble": {
                "distance": 300,
                "size": 3,
                "duration": 0.2,
                "opacity": 0.2,
                "speed": 3
            },
            "repulse": {
                "distance": 50,
                "duration": 1
            },
            "push": {
                "particles_nb": 4
            },
            "remove": {
                "particles_nb": 2
            }
        }
    },
    "retina_detect": true
};

var conf3 = {
  "particles": {
    "number": {
      "value": 15,
      "density": {
        "enable": true,
        "value_area": 500
      }
    },
    "color": {
      "value": "#000"
    },
    "shape": {
      "type": "image",
      "stroke": {
        "width": 0,
        "color": "#141414"
      },
      "polygon": {
        "nb_sides": 5
      },
      "image": {
        "src": "res/imgs/casa3netflix/Netflix-duster-3.png",
        "width": 100,
        "height": 100
      }
    },
    "opacity": {
      "value": 0.7,
      "random": true,
      "anim": {
        "enable": true,
        "speed": 1,
        "opacity_min": 0.5,
        "sync": false
      }
    },
    "size": {
      "value": 12,
      "random": true,
      "anim": {
        "enable": true,
        "speed": 2,
        "size_min": 7,
        "sync": false
      }
    },
    "line_linked": {
      "enable": false,
      "distance": 500,
      "color": "#ffffff",
      "opacity": 0.4,
      "width": 2
    },
    "move": {
      "enable": true,
      "speed": 0.3,
      "direction": "right",
      "random": true,
      "straight": false,
      "out_mode": "out",
      "bounce": false,
      "attract": {
        "enable": false,
        "rotateX": 600,
        "rotateY": 600
      }
    }
  },
  "interactivity": {
    "detect_on": "canvas",
    "events": {
      "onhover": {
        "enable": true,
        "mode": "bubble"
      },
      "onclick": {
        "enable": true,
        "mode": "bubble"
      },
      "resize": true
    },
    "modes": {
      "grab": {
        "distance": 400,
        "line_linked": {
          "opacity": 0.5
        }
      },
      "bubble": {
        "distance": 300,
        "size": 3,
        "duration": 0.2,
        "opacity": 0.2,
        "speed": 3
      },
      "repulse": {
        "distance": 50,
        "duration": 1
      },
      "push": {
        "particles_nb": 4
      },
      "remove": {
        "particles_nb": 2
      }
    }
  },
  "retina_detect": true
};
jQuery(document)
    .ready(function($) {
        /*if (CookieManager.getCookie('__trecp_v2')) {
            console.log('consenso ok');
        } else {
            if (CookieManager.getCookie('__trecp_v2')) {
                console.log('consenso ok');
            }
        }*/
        particlesJS
            .load('particles-js-1', conf1);

        particlesJS
            .load('particles-js-2', conf2);

        particlesJS
            .load('particles-js-3', conf3);

        $("body")
            .mousemove(function(e) {
                $(".particles-background")
                    .css('background-position', (e.pageX - 1920) + 'px ' + (e.pageY - 1800) + 'px');
            });

        setTimeout(function() {
            $('.logo-3, .logo-netflix,.action-switch')
                .addClass('text-flicker-in-glow');

            setTimeout(function() {
                $('.overlay-banner')
                    .fadeIn(1000);
            }, 3000);
        }, 4000);


        $('#s3inger_things--container')
            .on({
                'click': function(event) {
                    event
                        .preventDefault();
                    dissolveOverlay();

                }
            }, '.action-switch')
            .on({
                'click': function(event) {
                    event
                        .preventDefault();
                    dissolveOverlay();

                }
            }, '#particles-js-1, .overlay-header');

        $(window).on('load resize', function() {
            var wWidth = $(window).outerWidth();
            var $packImg = $('.pack-image');
            var packImg = $packImg.attr('src');
            console.log(packImg);
            if (wWidth <= 360) {

                if (window.matchMedia('only screen and (-webkit-min-device-pixel-ratio: 2)')) {
                    if (!packImg.match('pack-medium')) {
                        $packImg.attr('src', 'res/imgs/casa3netflix/pack-medium.png');
                    }
                } else {
                    if (!packImg.match('pack-small')) {
                        $packImg.attr('src', 'res/imgs/casa3netflix/pack-small.png');
                    }
                }


            } else if (wWidth > 360 && wWidth <= 640 && window.matchMedia('only screen and (-webkit-min-device-pixel-ratio: 2)')) {
                if (!packImg.match('pack-medium')) {
                    $packImg.attr('src', 'res/imgs/casa3netflix/pack-medium.png');
                }

            } else if (wWidth > 640) {
                if (!packImg.match('pack-large')) {
                    $packImg.attr('src', 'res/imgs/casa3netflix/pack-large.png');
                }
            }
        });
    });
